import time

# Take input from the user
arr = list(map(int, input("Enter numbers separated by spaces: ").split()))

print("Original array:", arr)

# Start measuring execution time
start_time = time.perf_counter()

# Bubble Sort
n = len(arr)

for i in range(n - 1):
    swapped = False

    for j in range(n - i - 1):
        if arr[j] > arr[j + 1]:
            # Swap adjacent elements
            arr[j], arr[j + 1] = arr[j + 1], arr[j]
            swapped = True

    # Stop if the array is already sorted
    if not swapped:
        break

# End measuring execution time
end_time = time.perf_counter()

execution_time = end_time - start_time

print("Sorted array:", arr)
print(f"Execution time: {execution_time:.10f} seconds")

# Complexity
print("\nTime Complexity:")
print("Best Case    : O(n)")
print("Average Case : O(n²)")
print("Worst Case   : O(n²)")

print("\nSpace Complexity: O(1)")
