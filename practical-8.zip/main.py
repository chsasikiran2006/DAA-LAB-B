from collections import deque
import time

# User input
n = int(input("Enter number of vertices: "))

graph = {}
for i in range(n):
    graph[i] = list(map(int, input(
        f"Enter adjacent vertices of {i} (space-separated): "
    ).split()))

start = int(input("Enter starting vertex: "))

# BFS
visited = set()
queue = deque([start])
visited.add(start)

start_time = time.perf_counter()

bfs_order = []

while queue:
    vertex = queue.popleft()
    bfs_order.append(vertex)

    for neighbor in graph[vertex]:
        if neighbor not in visited:
            visited.add(neighbor)
            queue.append(neighbor)

end_time = time.perf_counter()

print("BFS Traversal:", bfs_order)
print("Execution time:", end_time - start_time, "seconds")

# Time Complexity: O(V + E)
# Space Complexity: O(V)
